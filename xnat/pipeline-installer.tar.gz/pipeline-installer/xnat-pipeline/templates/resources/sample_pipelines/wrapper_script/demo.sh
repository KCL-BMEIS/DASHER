#!/bin/bash
#---------------------------------------------------------------------------
# A custom wrapper script
# This script just echoes all the arguments that it expects to get
#---------------------------------------------------------------------------

echo $1

echo $2

echo $3